// Interfícies de Range pel Grup B en float32.
// CreatedAt: 2025/01/03 dv. JIQ

package intf

// Interfície per a valors de 32 bits (float32) del Grup B.
type RangeF32GroupBIntf interface {
	RangeF32Intf
	GroupBIntf
}
