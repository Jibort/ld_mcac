// Interfícies de Range per a 64 bits.
// CreatedAt: 2025/01/03 dv. JIQ

package intf

// Interfície per a valors fixed o floating points de 32bits.
type Range32Intf interface {
	RangeIntf          // Hereta les funcions generals per a tots els Range32
	MathOperationsIntf // Hereta les funcions matemàtiques per a tots els Range32

	IsF32() bool       // Cert només si la instància és de 64 bits en punt flotant.
	IsU32() bool       // Cert només si la instància és de 64 bits en enter sense signe.
	As64() Range64Intf // Conversió a 64 bits
}
