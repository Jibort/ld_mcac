// Interfícies de Range per a 64 bits.
// CreatedAt: 2025/01/03 dv. JIQ

package intf

// Interfície per a valors fixed o floating points de 64bits.
type Range64Intf interface {
	RangeIntf          // Hereta les funcions generals per a tots els Range64
	MathOperationsIntf // Hereta les funcions matemàtiques per a tots els Range64

	IsF64() bool       // Cert només si la instància és de 64 bits en punt flotant.
	IsU64() bool       // Cert només si la instància és de 64 bits en enter sense signe.
	As32() Range32Intf // Conversió a 32 bits
}
