// Interfícies de Range pel Grup A en float64.
// CreatedAt: 2025/01/03 dv. JIQ

package intf

// Interfície per a valors de 64 bits (float64) del Grup A.
type RangeF64GroupAIntf interface {
	RangeF64Intf // Hereta les funcions generals per a float64
	GroupAIntf   // Hereta les funcions generals per a Grup A

	Exponent() uint16 // Retorna l'exponent com a uint16
	Mantissa() uint32 // Retorna la mantissa com a uint32
	IsOne() bool
	IsTwoPi() bool
}

type RangeF64OneIntf interface {
	RangeF64Intf
	RangeF64GroupAIntf
}

type RangeF64TwoPiIntf interface {
	RangeF64GroupAIntf
}

type OtherTwoPi struct {
	RangeF64TwoPiIntf
}
